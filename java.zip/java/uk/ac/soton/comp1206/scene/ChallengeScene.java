package uk.ac.soton.comp1206.scene;

import javafx.event.EventHandler;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import uk.ac.soton.comp1206.Multimedia;
import uk.ac.soton.comp1206.component.GameBlock;
import uk.ac.soton.comp1206.component.GameBoard;
import uk.ac.soton.comp1206.component.PieceBoard;
import uk.ac.soton.comp1206.event.NextPieceListener;
import uk.ac.soton.comp1206.game.Game;
import uk.ac.soton.comp1206.game.GamePiece;
import uk.ac.soton.comp1206.game.Grid;
import uk.ac.soton.comp1206.ui.GamePane;
import uk.ac.soton.comp1206.ui.GameWindow;

/**
 * The Single Player challenge scene. Holds the UI for the single player challenge mode in the game.
 */
public class ChallengeScene extends BaseScene {

    private static final Logger logger = LogManager.getLogger(MenuScene.class);
    protected Game game;
    PieceBoard prevPeice;
     /**
     * Create a new Single Player challenge scene
     * @param gameWindow the Game Window
     */
    public ChallengeScene(GameWindow gameWindow) {
        super(gameWindow);
        logger.info("Creating Challenge Scene");
    }

    /**
     * Build the Challenge window
     */
    @Override
    public void build() {
        logger.info("Building " + this.getClass().getName());

        setupGame();

        root = new GamePane(gameWindow.getWidth(), gameWindow.getHeight());

        var challengePane = new StackPane();
        challengePane.setMaxWidth(gameWindow.getWidth());
        challengePane.setMaxHeight(gameWindow.getHeight());
        challengePane.getStyleClass().add("menu-background");
        root.getChildren().add(challengePane);

        var mainPane = new BorderPane();
        challengePane.getChildren().add(mainPane);

        var board = new GameBoard(game.getGrid(),gameWindow.getWidth()/2,gameWindow.getWidth()/2);
        mainPane.setCenter(board);


        Grid prevGrid = new Grid(3,3);
        prevPeice = new PieceBoard(prevGrid, gameWindow.getWidth()/8, gameWindow.getWidth()/8);
        prevPeice.setTranslateX(-3*gameWindow.getWidth()/8);
        prevPeice.setTranslateY(-1*gameWindow.getHeight()/4);
        challengePane.getChildren().add(prevPeice);


        Text scorelbl = new Text("Score:");
        scorelbl.setFill(Color.WHITE);
        scorelbl.setFont(Font.font("Edwardian Script ITC", 40));
        scorelbl.setTranslateX(3*gameWindow.getWidth()/8-50);
        scorelbl.setTranslateY(-1*gameWindow.getHeight()/4);

        challengePane.getChildren().add(scorelbl);

        Text score = new Text();
        score.setFill(Color.WHITE);
        score.setFont(Font.font("Edwardian Script ITC", 40));
        score.setTranslateX(3*gameWindow.getWidth()/8+40);
        score.setTranslateY(-1*gameWindow.getHeight()/4);
        score.textProperty().bind(game.scoreProperty().asString());

        challengePane.getChildren().add(score);


        Text livelbl = new Text("Live:");
        livelbl.setFill(Color.WHITE);
        livelbl.setFont(Font.font("Orbitron", 20));
        livelbl.setTranslateX(3*gameWindow.getWidth()/8 - 30);
        livelbl.setTranslateY(-1*gameWindow.getHeight()/8);
        challengePane.getChildren().add(livelbl);

        Text live = new Text();
        live.setFill(Color.WHITE);
        live.setFont(Font.font("Orbitron", 20));
        live.setTranslateX(3*gameWindow.getWidth()/8 + 30);
        live.setTranslateY(-1*gameWindow.getHeight()/8);
        live.textProperty().bind(game.livesProperty().asString());

        challengePane.getChildren().add(live);


        Text multiplierlbl = new Text("Multiplier:");
        multiplierlbl.setFont(Font.font("Orbitron", 20));
        multiplierlbl.setFill(Color.WHITE);
        multiplierlbl.setTranslateX(3*gameWindow.getWidth()/8 - 40);
        multiplierlbl.setTranslateY(0);
        challengePane.getChildren().add(multiplierlbl);

        Text multiplier = new Text();
        multiplier.setFont(Font.font("Orbitron", 20));
        multiplier.setFill(Color.WHITE);
        multiplier.setTranslateX(3*gameWindow.getWidth()/8 + 40);
        multiplier.setTranslateY(0);
        multiplier.textProperty().bind(game.multiplierProperty().asString());
        challengePane.getChildren().add(multiplier);


        Text levellbl = new Text("Level:");
        levellbl.setFont(Font.font("Orbitron", 30));
        levellbl.setFill(Color.WHITE);
        levellbl.setTranslateX(3*gameWindow.getWidth()/8 - 40);
        levellbl.setTranslateY(gameWindow.getHeight()/8);
        challengePane.getChildren().add(levellbl);


        Text level = new Text();
        level.setFont(Font.font("Orbitron", 30));
        level.setFill(Color.WHITE);
        level.setTranslateX(3*gameWindow.getWidth()/8 + 40);
        level.setTranslateY(gameWindow.getHeight()/8);
        level.textProperty().bind(game.levelProperty().asString());
        challengePane.getChildren().add(level);

        //Handle block on gameboard grid being clicked, mouse entered
        board.setOnBlockClick(this::blockClicked);
        board.setOnBlockMouseEntered(this::blockMouseEntered);

        challengePane.setFocusTraversable(true);

        challengePane.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ESCAPE) {
                gameWindow.startMenu();
            }
            if (e.getCode() == KeyCode.R){
                game.swapCurrentPiece();
                prevPeice.updateBoard(game.getCurrentPiece());
                Multimedia.playaudio("rotate.wav");
            }
            if (e.getCode() == KeyCode.SPACE){
                game.swapCurrentPiece();
                prevPeice.updateBoard(game.getCurrentPiece());
                Multimedia.playaudio("rotate.wav");
            }

            if (e.getCode() ==  KeyCode.RIGHT){

            }
        });

        game.setNextPieceListener(this::nextPiece);

        Media media = new Media(getClass().getResource("/music/game.wav").toExternalForm());
        Multimedia.playbackmusic(media);

    }

    /**
     * Handle when a block is clicked
     * @param gameBlock the Game Block that was clocked
     */
    private void blockClicked(boolean bright, GameBlock gameBlock) {
        game.blockClicked(bright, gameBlock);
    }

    private void blockMouseEntered(int x, int y){
        game.blockMosueEntered(x, y);
    }
    /**
     * Setup the game object and model
     */
    public void setupGame() {
        logger.info("Starting a new challenge");

        //Start new game
        game = new Game(5, 5);
    }

    /**
     * Initialise the scene and start the game
     */
    @Override
    public void initialise() {
        logger.info("Initialising Challenge");
        game.start();

        scene.setOnKeyPressed(this::keyboardControls);
    }

    private void keyboardControls(KeyEvent keyEvent) {
        if (keyEvent.getCode()==KeyCode.LEFT);
    }


    private void nextPiece(GamePiece gamepiece)
    {
        prevPeice.updateBoard(gamepiece);
    }

}



