package uk.ac.soton.comp1206.scene;

import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.stage.Stage;
import uk.ac.soton.comp1206.ui.GamePane;
import uk.ac.soton.comp1206.ui.GameWindow;

import java.net.URL;

public class InstructionScene extends BaseScene {
    /**
     * Create a new scene, passing in the GameWindow the scene will be displayed in
     *
     * @param gameWindow the game window
     */
    ImageView img;
    public InstructionScene(GameWindow gameWindow) {
        super(gameWindow);
    }

    @Override
    public void initialise() {

    }

    @Override
    public void build() {
        root = new GamePane(gameWindow.getWidth(), gameWindow.getHeight());

        var challengePane = new StackPane();
        challengePane.setMaxWidth(gameWindow.getWidth());
        challengePane.setMaxHeight(gameWindow.getHeight());
        challengePane.setFocusTraversable(true);
        challengePane.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ESCAPE) {
                gameWindow.startMenu();
             }
        });


        root.getChildren().add(challengePane);

        var mainPane = new BorderPane();
        img = new ImageView(getClass().getResource("/images/Instructions.png").toExternalForm());
        img.fitWidthProperty().bind(gameWindow.getScene().widthProperty());
        img.setPreserveRatio(true);
        mainPane.setCenter(img);
        challengePane.getChildren().add(mainPane);

    }

}
