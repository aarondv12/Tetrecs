package uk.ac.soton.comp1206.scene;

import javafx.animation.Animation;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Text;
import javafx.util.Duration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import uk.ac.soton.comp1206.Multimedia;
import uk.ac.soton.comp1206.ui.GamePane;
import uk.ac.soton.comp1206.ui.GameWindow;

/**
 * The main menu of the game. Provides a gateway to the rest of the game.
 */
public class MenuScene extends BaseScene {

    private static final Logger logger = LogManager.getLogger(MenuScene.class);

    /**
     * Create a new menu scene
     * @param gameWindow the Game Window this will be displayed in
     */
    public MenuScene(GameWindow gameWindow) {
        super(gameWindow);
        logger.info("Creating Menu Scene");
    }

    /**
     * Build the menu layout
     */
    @Override
    public void build() {
        logger.info("Building " + this.getClass().getName());

        root = new GamePane(gameWindow.getWidth(),gameWindow.getHeight());

        var menuPane = new StackPane();
        menuPane.setMaxWidth(gameWindow.getWidth());
        menuPane.setMaxHeight(gameWindow.getHeight());
        menuPane.getStyleClass().add("menu-background");

        menuPane.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ESCAPE) {
                Platform.exit();
                System.exit(0);
            }
        });


        root.getChildren().add(menuPane);

        var mainPane = new BorderPane();
        menuPane.getChildren().add(mainPane);

        var menuBox = new VBox();
        mainPane.setCenter(menuBox);
        menuBox.setAlignment(Pos.CENTER);
        menuBox.setSpacing(11);

        //Awful title
        var title = new Text("TetrECS");
        title.getStyleClass().add("title");
        mainPane.setTop(title);

        //For now, let us just add a button that starts the game. I'm sure you'll do something way better.
        var button = new Button("Solo");
        menuBox.getChildren().add(button);
        button.getStyleClass().add("menuButtons");

        //Bind the button action to the startGame method in the menu
        button.setOnAction(this::startGame);
        Media media = new Media(getClass().getResource("/music/menu.mp3").toExternalForm());
        Multimedia.playbackmusic(media);


        var introbutton = new Button("Instructions");
        introbutton.setOnAction(this::showInstruction);
        ImageView imageView2 = new ImageView(getClass().getResource("/images/help.png").toExternalForm());
        menuBox.getChildren().add(introbutton);

        introbutton.getStyleClass().add("menuButtons");

        //title animation
        TranslateTransition titleTransition = new TranslateTransition();
        titleTransition.setDuration(Duration.millis(1000));
        titleTransition.setToY(50);
        titleTransition.setAutoReverse(true);
        titleTransition.setCycleCount(Animation.INDEFINITE);
        titleTransition.setNode(title);
        titleTransition.play();
    }




    /**
     * Initialise the menu
     */
    @Override
    public void initialise() {

    }

    /**
     * Handle when the Start Game button is pressed
     * @param event event
     */
    private void startGame(ActionEvent event) {
        gameWindow.startChallenge();
    }

    /**
     * Handle when the Start Game button is pressed
     * @param event event
     */
    private void showInstruction(ActionEvent event) {
        gameWindow.showInstruction();
    }


}
