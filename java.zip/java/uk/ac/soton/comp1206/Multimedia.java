package uk.ac.soton.comp1206;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;

import java.io.File;
import java.io.IOError;
import java.io.IOException;

public class Multimedia {
    private static MediaPlayer musicplayer;
    private static MediaPlayer audioplayer;


    public static void playaudio(String path){
        String audioPath =  Multimedia.class.getResource("/sounds/" + path).toExternalForm();

        try {
            Media media = new Media(audioPath);
            audioplayer  = new MediaPlayer(media);
            audioplayer.play();

        } catch (Exception e) {
            e.printStackTrace();
        }




    }
    public static void playbackmusic(Media media){
        musicplayer  = new MediaPlayer(media);
        musicplayer.setOnEndOfMedia(new Runnable() {
            public void run() {
                musicplayer.seek(Duration.ZERO);
            }
        });
        musicplayer.setAutoPlay(true);
    }
}
