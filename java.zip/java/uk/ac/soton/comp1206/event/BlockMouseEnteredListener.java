package uk.ac.soton.comp1206.event;

public interface BlockMouseEnteredListener {
    public void blockMouserEntered(int x, int y);
}
