package uk.ac.soton.comp1206.game;

import javafx.application.Platform;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import uk.ac.soton.comp1206.Multimedia;
import uk.ac.soton.comp1206.component.GameBlock;
import uk.ac.soton.comp1206.component.GameBlockCoordinate;
import uk.ac.soton.comp1206.event.BlockClickedListener;
import uk.ac.soton.comp1206.event.NextPieceListener;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

/**
 * The Game class handles the main logic, state and properties of the TetrECS game. Methods to manipulate the game state
 * and to handle actions made by the player should take place inside this class.
 */
public class Game {

    private static final Logger logger = LogManager.getLogger(Game.class);

    /**
     * Number of rows
     */
    protected final int rows;

    /**
     * Number of columns
     */
    protected final int cols;

    /**
     * The grid model linked to the game
     */
    protected final Grid grid;


    //    This will keep track of the current piece
    private GamePiece currentPiece;
    private GamePiece followingPiece;

    private boolean beforeclear = false;
    private boolean clear4 = false;
    SimpleIntegerProperty score, level, lives, multiplier;


    private NextPieceListener nextPieceListener;



    /**
     * Create a new game with the specified rows and columns. Creates a corresponding grid model.
     * @param cols number of columns
     * @param rows number of rows
     */
    public Game(int cols, int rows) {
        this.cols = cols;
        this.rows = rows;

        //Create a new grid model to represent the game state
        this.grid = new Grid(cols,rows);

         score =new SimpleIntegerProperty(0);
         level =new SimpleIntegerProperty(1);
         lives =new SimpleIntegerProperty(3);
         multiplier =new SimpleIntegerProperty(1);
    }

    /**
     * Start the game
     */
    public void start() {
        logger.info("Starting game");
        initialiseGame();
    }

    /**
     * Initialise a new game and set up anything that needs to be done at the start
     */
    public void initialiseGame() {
        logger.info("Initialising game");
        currentPiece = spawnPiece();
        followingPiece = spawnPiece();
        nextPieceListener.nextPiece(this.followingPiece);


    }
    /**
     * Handle what should happen when a particular block is clicked
     * @param gameBlock the block that was clicked
     */
    public void blockClicked(boolean bright, GameBlock gameBlock) {
        //Get the position of this block
        int x = gameBlock.getX();
        int y = gameBlock.getY();
        if(bright == false)
        {

            if(grid.canPlayPiece(x-1,y-1,currentPiece))
            {
                this.grid.playPiece(x-1,y-1,currentPiece);
                afterPiece();
                //fetch the next piece
                nextPiece();
            }
        }
        else{
            currentPiece.rotate();
            blockMosueEntered(x,y);
        }
        Multimedia.playaudio("rotate.wav");

    }

    public void blockMosueEntered(int x, int y)
    {
        logger.info("blockMosueEntered: {}", x);

        if(currentPiece == null) return;
        grid.setasreal();

        int [][]blocks = currentPiece.getBlocks();

        int tmpx, tmpy;
        for(int j =0; j<3;j++)
            for(int i=0; i<3; i++)
            {
                tmpx = i+ x- 1;
                tmpy = j+ y -1;
                if(blocks[i][j]>0){
                    if(tmpx<5 && tmpy<5 && tmpx>=0 && tmpy>=0)
                        grid.set(tmpx,tmpy,currentPiece.getValue());
                    else
                    {
                        grid.setasreal();
                        return;
                    }

                }
            }

    }


    /**
     * Get the grid model inside this game representing the game state of the board
     * @return game grid model
     */
    public Grid getGrid() {
        return grid;
    }

    /**
     * Get the number of columns in this game
     * @return number of columns
     */
    public int getCols() {
        return cols;
    }

    /**
     * Get the number of rows in this game
     * @return number of rows
     */
    public int getRows() {
        return rows;
    }


    //    Create a new random GamePiece by calling GamePiece.createPiece
    public GamePiece spawnPiece()
    {
        int range = 14;
        int rand = (int)(Math.random() * range) + 1;
        return GamePiece.createPiece(rand);

    }

    public void nextPiece()
    {
        this.currentPiece = this.followingPiece;
        this.followingPiece = spawnPiece();
        nextPieceListener.nextPiece(this.followingPiece);

    }

    //  Add an afterPiece method
    //• To be called after playing a piece
    //• This should clear any full vertical/horizontal lines that have been made
    public void afterPiece()
    {
        //from top to bottom
        ArrayList<GameBlockCoordinate> clearblocks = new ArrayList<GameBlockCoordinate>();

        int number_lines = 0;
        for(int j=0; j<rows; j++)
        {
            boolean bhorizontal = true;
            for(int i=0;i<cols; i++)
            {
                if(grid.get(i,j)==0) {
                    bhorizontal = false;
                    break;
                }
            }
            if(bhorizontal == true){
                number_lines++;
                for(int i=0;i<cols; i++)
                {
                    clearblocks.add(new GameBlockCoordinate(i,j));
                }
            }
        }

        //from left to right
        for(int i=0; i<cols; i++)
        {
            boolean bvertical = true;
            for(int j=0;j<rows; j++)
            {
                if(grid.get(i,j)==0) {
                    bvertical = false;
                    break;
                }
            }

            if(bvertical == true)
            {
                number_lines++;
                for(int j=0;j<rows;j++)
                    clearblocks.add(new GameBlockCoordinate(i,j));
            }
        }
        logger.info("score:{}", clearblocks.size());
        for(int i = 0; i< clearblocks.size(); i++)
        {
            GameBlockCoordinate coord = clearblocks.get(i);
            grid.set(coord.getX(), coord.getY(), 0);
            grid.setrealgrid(coord.getX(), coord.getY(), 0);
        }
        
        if(number_lines>0)
        {
            if(beforeclear == true)
            {
                multiplier.set(multiplier.get()+1);
            }
            else
            {
                if(number_lines==4)
                {
                    multiplier.set(multiplier.get()+1);
                    clear4 = true;
                }
                else
                {
                    if(clear4 == true)
                        multiplier.set(multiplier.get()+number_lines);
                    clear4 =false;
                }
            }
            beforeclear = true;
        }
        else
        {
            beforeclear = false;
            clear4 = false;
            multiplier.set(1);
        }
        
        int totalscore =score.get()+number_lines*clearblocks.size()*multiplier.get()*10;
        level.set(totalscore/1000+1);
        score.set(totalscore);
    }

    public void setNextPieceListener(NextPieceListener listener)
    {
        this.nextPieceListener = listener;
    }
    // to swap pieces

    public void swapCurrentPiece()
    {
        GamePiece temp = currentPiece;
        currentPiece = followingPiece;
        followingPiece = temp;
    }



    public final IntegerProperty scoreProperty() {
        return score;
    }
    public final IntegerProperty multiplierProperty() {
        return multiplier;
    }
    public final IntegerProperty livesProperty() {
        return lives;
    }
    public final IntegerProperty levelProperty() {
        return level;
    }

    public GamePiece getCurrentPiece(){
        return currentPiece;
    }



}
